<?php

return [
    'isDemo' => env('IS_DEMO', 'true'),
    'isVerified' => false,
];
