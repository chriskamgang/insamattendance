<?php

use App\Helper\Helper;

//if (!function_exists('checkUserRole')) {
//    function checkUserRole()
//    {
////        if ((!config('system.isVerified') && config('system.isDemo'))){
////            return true;
////        }
////        if ((config('system.isVerified') && !config('system.isDemo'))){
////            return true;
////        }
////        Helper::checkUrl();
////        return false;
//        return true;
//    }
//}
