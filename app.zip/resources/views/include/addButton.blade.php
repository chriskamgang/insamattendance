<a href="{{$route}}" class="btn btn-primary"><i class="link-icon" data-feather="plus"></i> {{$button_text}}</a>
