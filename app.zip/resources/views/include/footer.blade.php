<footer class="footer d-flex flex-column flex-md-row align-items-center justify-content-end px-4 py-3 border-top small">
    <p class="text-muted">Copyright {{date('Y')}}  @ <a href="https://cninfotech.com/" target="_blank">Cyclone Nepal Info Tech</a> | All Rights Reserved.</p>
</footer>

