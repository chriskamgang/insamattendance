$(function() {
  'use strict';

  $("fonedropzone").dropzone({
    url: '/file/post'
  });
});