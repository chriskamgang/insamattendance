$(function() {
  'use strict';

  $('#tags').tagsInput({
    'width': '100%',
    'height': '60%',
    'interactive': true,
    'defaultText': 'Add More',
    'removeWithBackspace': true,
    'minChars': 0,
    'maxChars': 20,
    'placeholderColor': '#666666'
  });

  $('#tags-dt1').tagsInput({
    'width': '90%',
    'height': '60%',
    'interactive': true,
    'defaultText': 'Add More',
    'removeWithBackspace': true,
    'minChars': 0,
    'maxChars': 20,
    'placeholderColor': '#666666'
  });
  $('#tags-dt2').tagsInput({
    'width': '90%',
    'height': '60%',
    'interactive': true,
    'defaultText': 'Add More',
    'removeWithBackspace': true,
    'minChars': 0,
    'maxChars': 20,
    'placeholderColor': '#666666'
  });
  $('#tags-dt3').tagsInput({
    'width': '90%',
    'height': '60%',
    'interactive': true,
    'defaultText': 'Add More',
    'removeWithBackspace': true,
    'minChars': 0,
    'maxChars': 20,
    'placeholderColor': '#666666'
  });
  $('#tags-dt4').tagsInput({
    'width': '90%',
    'height': '60%',
    'interactive': true,
    'defaultText': 'Add More',
    'removeWithBackspace': true,
    'minChars': 0,
    'maxChars': 20,
    'placeholderColor': '#666666'
  });
  $('#tags-dt5').tagsInput({
    'width': '90%',
    'height': '60%',
    'interactive': true,
    'defaultText': 'Add More',
    'removeWithBackspace': true,
    'minChars': 0,
    'maxChars': 20,
    'placeholderColor': '#666666'
  });
  $('#tags-dt6').tagsInput({
    'width': '90%',
    'height': '60%',
    'interactive': true,
    'defaultText': 'Add More',
    'removeWithBackspace': true,
    'minChars': 0,
    'maxChars': 20,
    'placeholderColor': '#666666'
  });
});